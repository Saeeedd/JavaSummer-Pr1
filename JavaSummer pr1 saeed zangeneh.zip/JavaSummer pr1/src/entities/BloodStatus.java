package entities;

public enum BloodStatus {
    Muggle, PureBlood, HalfBlood, MuggleBorn, Squibb;
}

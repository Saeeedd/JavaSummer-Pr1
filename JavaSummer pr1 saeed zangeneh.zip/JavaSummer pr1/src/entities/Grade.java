package entities;

public enum Grade {
    O, E, A, P, D, T;
}
